# xkill

> Kill a window interactively in a graphical session.
> See also `kill` and `killall`.

- Display a cursor to kill a window when pressing the left mouse button (press any other mouse button to cancel):

`xkill`
