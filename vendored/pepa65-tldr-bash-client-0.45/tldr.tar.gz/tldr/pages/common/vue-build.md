# vue build

> A subcommand provided by `@vue/cli` and `@vue/cli-service-global` that enables quick prototyping.
> More information: <https://cli.vuejs.org/guide/prototyping.html>.

- Build a `.js` or `.vue` file in production mode with zero config:

`vue build {{filename}}`
