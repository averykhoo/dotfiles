# wordgrinder

> Command-line word processor.
> More information: <https://cowlark.com/wordgrinder>.

- Start wordgrinder (loads a blank document by default):

`wordgrinder`

- Open a given file:

`wordgrinder {{filename}}`

- Show the menu:

`Alt + M`
