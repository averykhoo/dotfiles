# sh

> Bourne ljuska.
> Standardni interpreter komandnog jezika.

- Pokreni interaktivnu ljusku:

`sh`

- Izvrši komandu:

`sh -c {{komanda}}`

- Pokreni komande iz datoteke:

`sh {{datoteka.sh}}`

- Pokreni komande iz `stdin`-a:

`sh -s`
