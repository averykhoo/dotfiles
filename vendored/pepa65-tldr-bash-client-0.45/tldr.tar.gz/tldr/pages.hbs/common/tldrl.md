# tldrl

> Lintuje i formatira tldr stranice.
> Više informacija: <https://github.com/tldr-pages/tldr-lint>.

- Lintuj sve stranice:

`tldrl {{direktorijum_stranica}}`

- Formatiraj određenu stranicu u `stdout`:

`tldrl -f {{stranica.md}}`

- Formatiraj sve stranice na njihovom mestu:

`tldrl -fi {{direktorijum_stranica}}`
