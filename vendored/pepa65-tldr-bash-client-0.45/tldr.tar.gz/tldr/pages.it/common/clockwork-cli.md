# clockwork-cli

> Una interfaccia da linea di comando per il framework PHP Clockwork.
> Maggiori informazioni: <https://github.com/ptrofimov/clockwork-cli>.

- Monitora i log di Clockwork per il progetto corrente:

`clockwork-cli`

- Monitora i log di Clockwork per uno specifico progetto:

`clockwork-cli {{percorso/a/directory_progetto}}`

- Monitora i log di Clockwork per più progetti:

`clockwork-cli {{percorso/a/directory1 percorso/a/directory2 …}}`
