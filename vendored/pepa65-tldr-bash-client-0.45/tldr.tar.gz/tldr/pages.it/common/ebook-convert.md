# ebook-convert

> Converti ebook in differenti formati, come PDF, EPUB, Mobi.
> Parte dello strumento Calibre per librerie ebook.
> Maggiori informazioni: <https://manual.calibre-ebook.com/generated/en/ebook-convert.html>.

- Converti un ebook in un altro formato:

`ebook-convert {{originale}} {{convertito}}`
