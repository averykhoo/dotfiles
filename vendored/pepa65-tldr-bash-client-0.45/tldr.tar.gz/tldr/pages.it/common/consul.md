# consul

> Rete distribuita per gestire e configurare servizi tramite database chiave-valore.
> Maggiori informazioni: <https://www.consul.io/docs/commands/index.html>.

- Controlla la versione di Consul:

`consul --version`

- Mostra informazioni di aiuto generali:

`consul --help`

- Mostra aiuto per un sottocomando:

`consul {{sottocomando}} --help`
