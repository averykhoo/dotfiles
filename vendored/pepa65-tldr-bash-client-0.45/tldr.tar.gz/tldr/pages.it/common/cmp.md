# cmp

> Compara due file.

- Trova l'indice del primo byte e della prima riga differente tra due file:

`cmp {{file1}} {{file2}}`

- Trova ogni coppia di byte differenti ed il relativo indice:

`cmp -l {{file1}} {{file2}}`
