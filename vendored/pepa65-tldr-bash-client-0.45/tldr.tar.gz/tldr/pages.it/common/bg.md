# bg

> Riprende job che sono stati sospesi (e.g. usando `Ctrl + Z`) mettendoli in esecuzione in background.

- Riprendi il job sospeso più recentemente ed eseguilo in background:

`bg`

- Riprendi uno specifico job (usa `jobs -l` per trovare l'ID) ed eseguilo in background:

`bg {{id_job}}`
