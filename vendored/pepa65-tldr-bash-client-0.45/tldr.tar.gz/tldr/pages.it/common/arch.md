# arch

> Mostra il nome dell'architettura del sistema.
> Vedi anche `uname`.

- Mostra l'architettura del sistema:

`arch`
