# cd

> Cambia la directory corrente.

- Vai alla directory specificata:

`cd {{percorso/a/directory}}`

- Vai alla directory home dell'utente corrente:

`cd`

- Vai alla directory madre della corrente:

`cd ..`

- Vai alla directory precedentemente scelta:

`cd -`
