# cradle

> Il framework Cradle per PHP.
> Vedi `cradle-install`, `cradle-deploy` e altre pagine per maggiori informazioni.
> Maggiori informazioni: <https://cradlephp.github.io>.

- Connetti ad un server:

`cradle connect {{nome_server}}`

- Mostra informazioni di aiuto generali:

`cradle help`

- MOstra aiuto per uno specifico comando:

`cradle {{command}} help`

- Esegui un comando Cradle:

`cradle {{command}}`
