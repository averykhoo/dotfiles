# dive

> Un tool per esplorare immagini Docker, contenuti dei livelli, e ridurne la dimensione.
> Maggiori informaizoni: <https://github.com/wagoodman/dive>.

- Analizza un'immaigine Docker:

`dive {{tag_immagine}}`

- Costruisci un'immagine ed avvia l'analisi:

`dive build -t {{tag}}`
