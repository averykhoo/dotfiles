# git

> Sistema di controllo versione distribuito.
> Maggiori informazioni: <https://git-scm.com/>.

- Controlla la versione di git:

`git --version`

- Mostra informazioni di aiuto generali:

`git --help`

- Mostra aiuto per uno specifico comando:

`git help {{command}}`

- Esegui un comando git:

`git {{command}}`
