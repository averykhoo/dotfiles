# cksum

> Calcola checksum CRC e conta i byte di un file.
> Nota: in vecchi sistemi UNIX l'implementazione di CRC potrebbe essere diversa.

- Calcola e mostra un checksum di 32 bit, dimensione in byte e nome del file:

`cksum {{percorso/al/file}}`
