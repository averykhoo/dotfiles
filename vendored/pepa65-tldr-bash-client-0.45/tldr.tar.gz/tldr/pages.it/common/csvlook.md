# csvlook

> Visualizza un file CSV nella console come tabella a larghezza fissa.
> Incluso in csvkit.
> Maggiori informazioni: <https://csvkit.readthedocs.io/en/latest/scripts/csvlook.html>.

- Visualizza un file CSV:

`csvlook {{data.csv}}`
