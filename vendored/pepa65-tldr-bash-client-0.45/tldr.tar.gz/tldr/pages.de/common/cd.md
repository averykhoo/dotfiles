# cd

> Ändern des aktuellen Arbeitsverzeichnis.

- Wechsel in das angegebene Verzeichnis:

`cd {{pfad/zum/verzeichnis}}`

- Zum Home-Verzeichnis des aktuellen Benutzers gehen:

`cd`

- Gehe zum übergeordneten Verzeichnis des aktuellen Verzeichnisses:

`cd ..`

- Gehe zum vorher gewählten Verzeichnis:

`cd -`
