# whoami

> Ausgabe des Benutzernamens des aktuellen Benutzers.

- Ausgabe des aktiven Benutzernamens:

`whoami`

- Ausgabe des Benutzernamens nach einer Änderung der Benutzer Identität:

`sudo whoami`
