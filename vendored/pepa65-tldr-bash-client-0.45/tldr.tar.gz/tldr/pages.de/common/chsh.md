# chsh

> Login-Shell des Benutzers ändern.

- Shell ändern:

`chsh -s {{pfad/zum/shell_programm}} {{benutzername}}`
