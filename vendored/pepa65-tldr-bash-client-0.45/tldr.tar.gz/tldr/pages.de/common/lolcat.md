# lolcat

> Ausgabe von Befehl in Regenbogenfarben einfärben.
> Mehr Informationen: <https://github.com/busyloop/lolcat>.

- Inhalt von Datei in Regenbogenfarben zur Konsole schreiben:

`lolcat {{pfad/zur/datei}}`

- Ausgabe von Befehl in Regenbogenfarben zur Konsole schreiben:

`{{fortune}} | lolcat`

- Inhalt von Datei in animierten Regenbogenfarben zur Konsole schreiben:

`lolcat -a {{pfad/zur/datei}}`

- Inhalt von Datei in 24-bit (truecolor) Regenbogenfarben zur Konsole schreiben:

`lolcat -t {{pfad/zur/datei}`
