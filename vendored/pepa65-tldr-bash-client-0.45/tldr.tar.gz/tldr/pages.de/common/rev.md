# rev

> Kehre die Reihenfolge von Text um.

- Kehre die Reihenfolge des Textes "Hallo" um:

`echo "Hallo" | rev`

- Kehre die Reihenfolge einer Datei um:

`rev {{datei}}`
