# nano

> Editor sencillo y fácil de usar. Un clon libre y mejorado de Pico.
> Más información: <https://nano-editor.org>.

- Inicia nano en la terminal con {nombre_del_archivo}:

`nano {{nombre_del_archivo}}`

- Activar desplazamiento suave:

`nano -S {{nombre_del_archivo}}`

- Sangra las nuevas líneas a la sangría de las líneas anteriores:

`nano -i {{nombre_del_archiv}}`
