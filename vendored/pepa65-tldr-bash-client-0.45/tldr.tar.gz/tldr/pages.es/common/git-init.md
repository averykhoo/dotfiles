# git init

> Inicializa un nuevo repositorio git local.
> Más información: <https://git-scm.com/docs/git-init>.

- Inicializa un nuevo repositorio local:

`git init`

- Inicializa un repositorio vacío, adecuado para usarlo como remoto a través de ssh:

`git init --bare`
