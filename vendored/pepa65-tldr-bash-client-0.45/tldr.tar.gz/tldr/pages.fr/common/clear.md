# clear

> Efface l'écran du terminal.

- Effacer l'écran (identique à la séquence Contrôle-L sur une interface bash) :

`clear`
