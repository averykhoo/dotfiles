# cd

> Modifier le répertoire de travail courant.

- Se déplacer vers le dossier donné :

`cd {{chemin/vers/dossier}}`

- Se déplacer vers le répertoire personnel de l'utilisateur actuel :

`cd`

- Remonter vers le parent du répertoire courant :

`cd ..`

- Revenir au répertoire précédent :

`cd -`
