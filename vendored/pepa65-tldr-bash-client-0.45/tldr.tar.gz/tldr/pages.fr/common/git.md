# git

> Système de gestion de versions décentralisé.
> Plus d'informations : <https://git-scm.com/>.

- Obtenir la version de Git :

`git --version`

- Afficher l'aide générale :

`git --help`

- Afficher l'aide sur une commande Git :

`git help {{command}}`

- Exécuter une commande Git :

`git {{command}}`
